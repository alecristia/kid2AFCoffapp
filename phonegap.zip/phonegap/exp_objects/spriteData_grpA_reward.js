//Spécifications des stimuli pour le groupe A:
// ballePF
// voiturePC
// manteauPA
// bananePF
// yeuxPC
// compotePA
// bouteillePF
// lunettesPC
// maisonPA
// bateauPF
// fleurPC
// poissonPA

var spriteRewardData = {
	balle: {
		start: 1.273,
		onset: 1.273,
		length: 1.000
	},
	voiture: {
		start: 3.093,
		onset: 3.093,
		length: 1.000
	},
	manteau: {
		start: 5.097,
		onset: 5.097,
		length: 1.000
	},
	banane: {
		start: 6.991,
		onset: 6.991,
		length: 1.000
	}
};	